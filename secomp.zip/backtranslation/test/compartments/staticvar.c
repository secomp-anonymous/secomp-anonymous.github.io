//#include <stdio.h>

static §comp_main§ int ready = 0;

§comp_main§ int main() {
  ready = 1;
  return 0;
}
